<?php

// Conexão ao banco de dados (MySQL)
define("BD_SERVIDOR", "localhost");
define("BD_USUARIO", "sistematarefa");
define("BD_SENHA", "sistema");
define("BD_BANCO", "tarefas");

// E-mail para notificação
define("EMAIL_NOTIFICACAO", "meuemail@email.com");
