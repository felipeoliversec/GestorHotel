# Exemplos do livro "Desenvolvimento web com PHP e MySQL"

Estes são os exemplos mostrados no meu livro Desenvolvimento web com PHP e MySQL
lançado pela Casa do Código.

Mais informações aqui: http://www.casadocodigo.com.br/products/livro-php-mysql

## Arquivos .dia

Para desenhar os diagramas usados no livro eu usei o editor Dia. O Dia
é um software livre e pode ser obtido aqui: https://wiki.gnome.org/action/show/Apps/Dia?action=show&redirect=Dia
